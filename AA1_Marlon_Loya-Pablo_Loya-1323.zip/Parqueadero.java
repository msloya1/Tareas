import java.util.ArrayList;
import java.util.Scanner;

// Clase Vehiculo
class Vehiculo {  
    private static int contadorId = 1;
    private final int id;
    private String placa;
    private String marca;
    private String modelo;
    private boolean estado; // true: Estacionado, false: Retirado

    public Vehiculo(String placa, String marca, String modelo, boolean estado) {
        this.id = contadorId++;
        this.placa = placa;
        this.marca = marca;
        this.modelo = modelo;
        this.estado = estado;
    }

    public int getId() {
        return id;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    @Override
    public String toString() {
        return "ID: " + id + ", Placa: " + placa + ", Marca: " + marca + ", Modelo: " + modelo + ", Estado: " + (estado ? "Estacionado" : "Retirado");
    }
}

// Clase Parqueadero
class Parqueadero {  
    private ArrayList<Vehiculo> vehiculos;

    public Parqueadero() {
        this.vehiculos = new ArrayList<>();
    }

    public void registrarVehiculo(String placa, String marca, String modelo, boolean estado) {
        Vehiculo vehiculo = new Vehiculo(placa, marca, modelo, estado);
        vehiculos.add(vehiculo);
        System.out.println("Vehículo registrado: " + vehiculo.getPlaca() + " con ID: " + vehiculo.getId());
    }

    public void consultarVehiculos() {
        System.out.println("\n--- Lista de Vehículos ---");
        if (vehiculos.isEmpty()) {
            System.out.println("No hay vehículos registrados.");
        } else {
            for (Vehiculo vehiculo : vehiculos) {
                System.out.println(vehiculo);
            }
        }
    }

    public void actualizarEstadoVehiculo(int id, boolean nuevoEstado) {
        Vehiculo vehiculo = buscarVehiculo(id);
        if (vehiculo != null) {
            vehiculo.setEstado(nuevoEstado);
            System.out.println("Estado del vehículo actualizado a: " + (nuevoEstado ? "Estacionado" : "Retirado"));
        } else {
            System.out.println("Vehículo no encontrado.");
        }
    }

    private Vehiculo buscarVehiculo(int id) {
        for (Vehiculo vehiculo : vehiculos) {
            if (vehiculo.getId() == id) {
                return vehiculo;
            }
        }
        return null;
    }
}

// Clase Principal
public class Main {
    public static void main(String[] args) {
        Parqueadero parqueadero = new Parqueadero();
        Scanner scanner = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("\n--- Menú del Parqueadero ---");
            System.out.println("1. Registrar vehículo");
            System.out.println("2. Consultar vehículos");
            System.out.println("3. Actualizar estado de vehículo");
            System.out.println("4. Salir");
            System.out.print("Ingrese una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiar buffer

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese la placa del vehículo: ");
                    String placa = scanner.nextLine();
                    System.out.print("Ingrese la marca del vehículo: ");
                    String marca = scanner.nextLine();
                    System.out.print("Ingrese el modelo del vehículo: ");
                    String modelo = scanner.nextLine();
                    System.out.print("Ingrese el estado del vehículo (true: Estacionado, false: Retirado): ");
                    boolean estado = scanner.nextBoolean();
                    scanner.nextLine();
                    parqueadero.registrarVehiculo(placa, marca, modelo, estado);
                    break;

                case 2:
                    parqueadero.consultarVehiculos();
                    break;

                case 3:
                    System.out.print("Ingrese el ID del vehículo: ");
                    int id = scanner.nextInt();
                    System.out.print("Ingrese el nuevo estado (true: Estacionado, false: Retirado): ");
                    boolean nuevoEstado = scanner.nextBoolean();
                    scanner.nextLine();
                    parqueadero.actualizarEstadoVehiculo(id, nuevoEstado);
                    break;

                case 4:
                    System.out.println("Saliendo del sistema...");
                    break;

                default:
                    System.out.println("Opción no válida.");
            }
        } while (opcion != 4);

        scanner.close();
    }
}

