package Database;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;
import com.mongodb.client.model.Filters;

public class CrudMongo {
    private MongoClient mongoClient;
    private MongoDatabase database;
    private MongoCollection<Document> collection;

    public void iniciarConexion() {
        try {
            mongoClient = new MongoClient("localhost", 27017);
            database = mongoClient.getDatabase("App");
            collection = database.getCollection("EstudiantesData");
            System.out.println("Conexión con MongoDB establecida.");
        } catch (Exception e) {
            System.err.println("Error al conectar con MongoDB: " + e.getMessage());
        }
    }

    public void insertarEstudiante(Document estudiante) {
        try {
            collection.insertOne(estudiante);
            System.out.println("Estudiante insertado correctamente.");
        } catch (Exception e) {
            System.err.println("Error al insertar estudiante: " + e.getMessage());
        }
    }

    public Document buscarEstudiante(String nombre) {
        try {
            return collection.find(Filters.eq("nombre_estudiante", nombre)).first();
        } catch (Exception e) {
            System.err.println("Error al buscar estudiante: " + e.getMessage());
            return null;
        }
    }
}
