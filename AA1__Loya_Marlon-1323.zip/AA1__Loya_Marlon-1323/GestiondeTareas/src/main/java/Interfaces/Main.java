package Interfaces;  // Ahora pertenece al paquete "Interfaces"

import Database.CrudMongo;
import Database.Global;

import Interfaces.Login;

public class Main {
    public static void main(String[] args) {
        System.out.println("Iniciandoooo .");
        // Iniciar la conexión con MongoDB
        CrudMongo crudMongo = new CrudMongo();
        crudMongo.iniciarConexion();

        // Hacer que el CRUD esté disponible para los formularios
        Global.crudMongo = crudMongo;

        // Mostrar la pantalla de login
        Login log = new Login();
        log.setVisible(true);
        log.setLocationRelativeTo(null);
    }
}
